import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import styles from './page.module.css';

export default function Contato() {
    return (
        <main>
            <Navbar />

            <section className={styles.container}>
                <div className={`container ${styles.content}`}>
                    <div className={styles.info}>
                        <h1>Vamos Conversar?</h1>
                        <p>
                            Seja para transformar a gestão do seu restaurante ou para abastecer sua loja com as melhores marcas, estou pronto para ajudar.
                        </p>

                        <div className={styles.contactMethods}>
                            <div className={styles.method}>
                                <span className={styles.icon}>📞</span>
                                <a href="https://wa.me/5573981349085" target="_blank" rel="noopener noreferrer">
                                    (73) 9 8134-9085
                                </a>
                            </div>
                            <div className={styles.method}>
                                <span className={styles.icon}>📧</span>
                                <a href="mailto:eu@felipenb.com.br">eu@felipenb.com.br</a>
                            </div>
                            <div className={styles.method}>
                                <span className={styles.icon}>🌐</span>
                                <a href="https://felipenb.com.br">felipenb.com.br</a>
                            </div>
                        </div>
                    </div>

                    <div className={styles.form}>
                        <h3 style={{ marginBottom: '1.5rem', color: 'var(--accent)' }}>Envie uma mensagem rápida</h3>
                        <p style={{ marginBottom: '2rem', color: '#ccc' }}>
                            A forma mais rápida de falar comigo é pelo WhatsApp. Clique no botão abaixo para iniciar a conversa.
                        </p>

                        <a
                            href="https://wa.me/5573981349085"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="btn-primary"
                            style={{ width: '100%', textAlign: 'center', display: 'block' }}
                        >
                            Chamar no WhatsApp
                        </a>
                    </div>
                </div>
            </section>

            <Footer />
        </main>
    );
}
