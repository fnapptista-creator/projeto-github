import styles from './Footer.module.css';

export default function Footer() {
    return (
        <footer className={styles.footer}>
            <div className={`container ${styles.content}`}>
                <div className={styles.info}>
                    <h3 className={styles.footerTitle}>Felipe Nascimento</h3>
                    <p className={styles.footerSubtitle}>Consultor Gastronômico & Representante Comercial</p>

                    <div className={styles.contactList}>
                        <a href="https://wa.me/5573981349085" target="_blank" rel="noopener noreferrer" className={styles.contactItem}>
                            <span>📞</span> (73) 9 8134-9085
                        </a>
                        <a href="mailto:eu@felipenb.com.br" className={styles.contactItem}>
                            <span>✉️</span> eu@felipenb.com.br
                        </a>
                    </div>
                </div>

                <div className={styles.links}>
                    <a href="https://felipenb.com.br" className={styles.linkItem}>Consultoria: felipenb.com.br</a>
                    <a href="https://felipe.rep.br" className={styles.linkItem}>Catálogos: felipe.rep.br</a>
                </div>

                <div className={styles.copyright}>
                    &copy; {new Date().getFullYear()} Felipe Nascimento. Todos os direitos reservados.
                </div>
            </div>
        </footer>
    );
}
